import React from 'react'

const Privatepage = () => {
  return (
    <div>Add To Card</div>
  )
}

export default Privatepage