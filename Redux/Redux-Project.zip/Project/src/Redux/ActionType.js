export const PRODUCT_LOADING = "PRODUCT_LOADING";
export const PRODUCT_Data = "PRODUCT_Data";
export const PRODUCT_Error = "PRODUCT_Error";